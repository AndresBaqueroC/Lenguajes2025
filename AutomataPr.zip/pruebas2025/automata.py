import re
import sys

# lee y procesa las reglas
def leer_configuracion(archivo):
    with open(archivo, 'r') as f:
        contenido = f.read()
        
    # obtiene reglas iniciales usando expresiones regulares
    Q = re.search(r'Q=(.*)', contenido).group(1).split(',')
    E = re.search(r'E=(.*)', contenido).group(1).split(',')
    
    transiciones = {}
    for match in re.finditer(r'\((\w+),(\d+)\)=(\w+)', contenido):
        estado_actual = match.group(1)
        simbolo = match.group(2)
        estado_siguiente = match.group(3)
        if estado_actual not in transiciones:
            transiciones[estado_actual] = {}
        transiciones[estado_actual][simbolo] = estado_siguiente
    
    q0 = re.search(r'q0=\s*(\w+)', contenido).group(1)
    F = re.search(r'F=\s*(\w+)', contenido).group(1)
    
    return Q, E, transiciones, q0, F

# Función para simular el autómata
def simular_AFD(cadena, Q, E, transiciones, q0, F):
    estado_actual = q0
    for simbolo in cadena:
        if simbolo in transiciones[estado_actual]:
            estado_actual = transiciones[estado_actual][simbolo]
        else:
            return False  #cadena es rechazada
    
    return estado_actual == F  # Aceptar la cadena
    
def main():
    if len(sys.argv) != 3:
        print("Uso: falta algo paraque funcione.")
        sys.exit(1)

    #archivos q recibe
    reglas_file = sys.argv[1]
    prueba_file = sys.argv[2]
    
    Q, E, transiciones, q0, F = leer_configuracion(reglas_file)
    
    # Leer las cadenas de prueba
    with open(prueba_file, 'r') as f:
        cadenas = f.read().splitlines()
    
    # Probar cada cadena
    for cadena in cadenas:
        if simular_AFD(cadena, Q, E, transiciones, q0, F):
            print(f'La cadena "{cadena}" es aceptada.')
        else:
            print(f'La cadena "{cadena}" es rechazada.')

if __name__ == "__main__":
    main()

