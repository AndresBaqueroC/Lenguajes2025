#!/usr/bin/env python3
import sys
import re

def Gramatica3(cadena):
    
    patron_valido = re.fullmatch(r'^a+b+$', cadena) is not None
    
    conteo_a = len(re.findall('a', cadena))
    conteo_b = len(re.findall('b', cadena))
    
    return patron_valido and ((conteo_a == 1 and conteo_b == 1) or 
                            (conteo_a == 1 and conteo_b == 2))

def procesar_archivo(nombre_archivo):
    try:
        with open(nombre_archivo, 'r') as f:
            for linea in f:
                cadena = linea.strip()
                if Gramatica3(cadena):
                    print(f'La cadena "{cadena}"  aceptada.')
                else:
                    print(f'La cadena "{cadena}" No acepta.')
    except FileNotFoundError:
        print(f'El archivo "{nombre_archivo}" no existe')
        sys.exit(1)

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Uso: python3 G3.py archivo.txt")
        sys.exit(1)
    
    nombre_archivo = sys.argv[1]  
    procesar_archivo(nombre_archivo)
