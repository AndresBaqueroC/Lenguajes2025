#!/usr/bin/env python3
import re
import sys

def validar_gramatica(cadena):
    """
    Valida si la cadena cumple con la gramática a(ab)^n b donde n >= 0
    """
    patron = r'^a(ab)*b$'
    return re.fullmatch(patron, cadena) is not None

def procesar_archivo(nombre_archivo):
    try:
        with open(nombre_archivo, 'r') as f:
            for linea in f:
                cadena = linea.strip()
                if validar_gramatica(cadena):
                    print(f"'{cadena}': aceptado")
                else:
                    print(f"'{cadena}': No aceptado")
    except FileNotFoundError:
        print(f"Error: Archivo '{nombre_archivo}' no encontrado")
        sys.exit(1)

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Uso: python3 gramatica.py archivo.txt")
        sys.exit(1)
    
    procesar_archivo(sys.argv[1])
