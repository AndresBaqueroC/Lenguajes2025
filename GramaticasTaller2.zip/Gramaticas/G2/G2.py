
import re
import sys

def verificar_gramatica(cadena):
    conteo_a = len(re.findall(r'a', cadena))
    conteo_b = len(re.findall(r'b', cadena))
    
    patron_valido = re.fullmatch(r'^a*b+$', cadena) is not None
    return patron_valido and (conteo_b == conteo_a + 1)

def procesar_archivo(nombre_archivo):
    try:
        print("\nResultados:")
        with open(nombre_archivo, 'r') as f:
            for linea in f:
                cadena = linea.strip()
                if cadena:
                    if verificar_gramatica(cadena):
                        print(f"'{cadena}': aceptado")
                    else:
                        print(f"'{cadena}': no aceptado")
    except FileNotFoundError:
        print(f"Error: El archivo '{nombre_archivo}' no existe.")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: python3 gramatica_regular.py archivo.txt")
        sys.exit(1)
    
    nombre_archivo = sys.argv[1]
    procesar_archivo(nombre_archivo)
