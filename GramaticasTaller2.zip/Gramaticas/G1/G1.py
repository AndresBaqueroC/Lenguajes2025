import re
import sys

def es_capicua_binaria(cadena):
    if not re.fullmatch(r'[01]+', cadena):
        return False
    return cadena == cadena[::-1] 

def procesar_archivo(nombre_archivo):
    try:
        with open(nombre_archivo, 'r') as f:
            for linea in f:
                cadena = linea.strip()
                if es_capicua_binaria(cadena):
                    print(f"'{cadena}': aceptado")
                else:
                    print(f"'{cadena}': no aceptado")
    except FileNotFoundError:
        print(f"Error: Archivo '{nombre_archivo}' no encontrado")
        sys.exit(1)

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Uso: python3 capicuas.py archivo.txt")
        sys.exit(1)
    
    procesar_archivo(sys.argv[1])
