from LabeledExprVisitor import LabeledExprVisitor
from LabeledExprParser import LabeledExprParser
import math

class EvalVisitor(LabeledExprVisitor):
    def __init__(self):
        self.memory = {}  
    
    # ID '=' expr NEWLINE
    def visitAssign(self, ctx: LabeledExprParser.AssignContext):
        id = ctx.ID().getText()
        value = self.visit(ctx.expr())
        self.memory[id] = value
        return value
    
    # expr NEWLINE
    def visitPrintExpr(self, ctx: LabeledExprParser.PrintExprContext):
        value = self.visit(ctx.expr())
        if value % 1 == 0:
            print(int(value))
        else:
            print(f"{value:.6f}")
        return 0.0
    
    # NUM
    def visitNum(self, ctx: LabeledExprParser.NumContext):
        return float(ctx.NUM().getText())
    
    # ID
    def visitId(self, ctx: LabeledExprParser.IdContext):
        id = ctx.ID().getText()
        return self.memory.get(id, 0.0)
    
    # expr op=('*'|'/') expr
    def visitMulDiv(self, ctx: LabeledExprParser.MulDivContext):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        if ctx.op.type == LabeledExprParser.MUL:
            return left * right
        else:
            return left / right
    
    # expr op=('+'|'-') expr
    def visitAddSub(self, ctx: LabeledExprParser.AddSubContext):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        if ctx.op.type == LabeledExprParser.ADD:
            return left + right
        else:
            return left - right
    
    # '(' expr ')'
    def visitParens(self, ctx: LabeledExprParser.ParensContext):
        return self.visit(ctx.expr())
    
    # sin(expr)
    def visitSin(self, ctx: LabeledExprParser.SinContext):
        value = self.visit(ctx.expr())
        return math.sin(math.radians(value))
    
    # cos(expr)
    def visitCos(self, ctx: LabeledExprParser.CosContext):
        value = self.visit(ctx.expr())
        return math.cos(math.radians(value))
    
    # tan(expr)
    def visitTan(self, ctx: LabeledExprParser.TanContext):
        value = self.visit(ctx.expr())
        return math.tan(math.radians(value))
    
    # sqrt(expr)
    def visitSqrt(self, ctx: LabeledExprParser.SqrtContext):
        value = self.visit(ctx.expr())
        if value < 0:
            print(f"Error: No se puede calcular raíz de número negativo: {value}", file=sys.stderr)
            return float('nan')
        return math.sqrt(value)
    
    # expr '!' - factorial
    def visitFactorial(self, ctx: LabeledExprParser.FactorialContext):
        value = self.visit(ctx.expr())
        
        if value < 0 or value % 1 != 0:
            print(f"Error: El factorial solo está definido para enteros no negativos: {value}", file=sys.stderr)
            return float('nan')
        
        n = int(value)
        if n == 0 or n == 1:
            return 1.0
        
        result = 1
        for i in range(2, n + 1):
            result *= i
        
        return float(result)
    
    # ln(expr)
    def visitLn(self, ctx: LabeledExprParser.LnContext):
        value = self.visit(ctx.expr())
        if value <= 0:
            print(f"Error: El logaritmo natural solo está definido para números positivos: {value}", file=sys.stderr)
            return float('nan')
        return math.log(value)
    
    # log(expr)
    def visitLog(self, ctx: LabeledExprParser.LogContext):
        value = self.visit(ctx.expr())
        if value <= 0:
            print(f"Error: El logaritmo base 10 solo está definido para números positivos: {value}", file=sys.stderr)
            return float('nan')
        return math.log10(value)
    
    # singleAtom
    def visitSingleAtom(self, ctx: LabeledExprParser.SingleAtomContext):
        return self.visit(ctx.atom())
