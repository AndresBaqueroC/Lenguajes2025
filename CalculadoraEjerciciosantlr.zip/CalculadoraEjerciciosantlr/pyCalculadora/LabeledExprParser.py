# Generated from LabeledExpr.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,18,79,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,1,0,4,0,10,8,0,11,0,12,
        0,11,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,23,8,1,1,2,1,2,1,2,
        1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,5,2,36,8,2,10,2,12,2,39,9,2,1,3,
        1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,
        1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,
        1,3,1,3,1,3,3,3,77,8,3,1,3,0,1,4,4,0,2,4,6,0,2,1,0,4,5,1,0,6,7,88,
        0,9,1,0,0,0,2,22,1,0,0,0,4,24,1,0,0,0,6,76,1,0,0,0,8,10,3,2,1,0,
        9,8,1,0,0,0,10,11,1,0,0,0,11,9,1,0,0,0,11,12,1,0,0,0,12,1,1,0,0,
        0,13,14,3,4,2,0,14,15,5,17,0,0,15,23,1,0,0,0,16,17,5,15,0,0,17,18,
        5,1,0,0,18,19,3,4,2,0,19,20,5,17,0,0,20,23,1,0,0,0,21,23,5,17,0,
        0,22,13,1,0,0,0,22,16,1,0,0,0,22,21,1,0,0,0,23,3,1,0,0,0,24,25,6,
        2,-1,0,25,26,3,6,3,0,26,37,1,0,0,0,27,28,10,4,0,0,28,29,7,0,0,0,
        29,36,3,4,2,5,30,31,10,3,0,0,31,32,7,1,0,0,32,36,3,4,2,4,33,34,10,
        1,0,0,34,36,5,8,0,0,35,27,1,0,0,0,35,30,1,0,0,0,35,33,1,0,0,0,36,
        39,1,0,0,0,37,35,1,0,0,0,37,38,1,0,0,0,38,5,1,0,0,0,39,37,1,0,0,
        0,40,77,5,16,0,0,41,77,5,15,0,0,42,43,5,2,0,0,43,44,3,4,2,0,44,45,
        5,3,0,0,45,77,1,0,0,0,46,47,5,9,0,0,47,48,5,2,0,0,48,49,3,4,2,0,
        49,50,5,3,0,0,50,77,1,0,0,0,51,52,5,10,0,0,52,53,5,2,0,0,53,54,3,
        4,2,0,54,55,5,3,0,0,55,77,1,0,0,0,56,57,5,11,0,0,57,58,5,2,0,0,58,
        59,3,4,2,0,59,60,5,3,0,0,60,77,1,0,0,0,61,62,5,12,0,0,62,63,5,2,
        0,0,63,64,3,4,2,0,64,65,5,3,0,0,65,77,1,0,0,0,66,67,5,13,0,0,67,
        68,5,2,0,0,68,69,3,4,2,0,69,70,5,3,0,0,70,77,1,0,0,0,71,72,5,14,
        0,0,72,73,5,2,0,0,73,74,3,4,2,0,74,75,5,3,0,0,75,77,1,0,0,0,76,40,
        1,0,0,0,76,41,1,0,0,0,76,42,1,0,0,0,76,46,1,0,0,0,76,51,1,0,0,0,
        76,56,1,0,0,0,76,61,1,0,0,0,76,66,1,0,0,0,76,71,1,0,0,0,77,7,1,0,
        0,0,5,11,22,35,37,76
    ]

class LabeledExprParser ( Parser ):

    grammarFileName = "LabeledExpr.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'='", "'('", "')'", "'*'", "'/'", "'+'", 
                     "'-'", "'!'", "'sin'", "'cos'", "'tan'", "'sqrt'", 
                     "'ln'", "'log'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "MUL", "DIV", "ADD", "SUB", "FACT", "SIN", "COS", 
                      "TAN", "SQRT", "LN", "LOG", "ID", "NUM", "NEWLINE", 
                      "WS" ]

    RULE_prog = 0
    RULE_stat = 1
    RULE_expr = 2
    RULE_atom = 3

    ruleNames =  [ "prog", "stat", "expr", "atom" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    MUL=4
    DIV=5
    ADD=6
    SUB=7
    FACT=8
    SIN=9
    COS=10
    TAN=11
    SQRT=12
    LN=13
    LOG=14
    ID=15
    NUM=16
    NEWLINE=17
    WS=18

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(LabeledExprParser.StatContext)
            else:
                return self.getTypedRuleContext(LabeledExprParser.StatContext,i)


        def getRuleIndex(self):
            return LabeledExprParser.RULE_prog

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProg" ):
                return visitor.visitProg(self)
            else:
                return visitor.visitChildren(self)




    def prog(self):

        localctx = LabeledExprParser.ProgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_prog)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 9 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 8
                self.stat()
                self.state = 11 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 261636) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return LabeledExprParser.RULE_stat

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class BlankContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NEWLINE(self):
            return self.getToken(LabeledExprParser.NEWLINE, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlank" ):
                return visitor.visitBlank(self)
            else:
                return visitor.visitChildren(self)


    class PrintExprContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(LabeledExprParser.ExprContext,0)

        def NEWLINE(self):
            return self.getToken(LabeledExprParser.NEWLINE, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrintExpr" ):
                return visitor.visitPrintExpr(self)
            else:
                return visitor.visitChildren(self)


    class AssignContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(LabeledExprParser.ID, 0)
        def expr(self):
            return self.getTypedRuleContext(LabeledExprParser.ExprContext,0)

        def NEWLINE(self):
            return self.getToken(LabeledExprParser.NEWLINE, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssign" ):
                return visitor.visitAssign(self)
            else:
                return visitor.visitChildren(self)



    def stat(self):

        localctx = LabeledExprParser.StatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_stat)
        try:
            self.state = 22
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                localctx = LabeledExprParser.PrintExprContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 13
                self.expr(0)
                self.state = 14
                self.match(LabeledExprParser.NEWLINE)
                pass

            elif la_ == 2:
                localctx = LabeledExprParser.AssignContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 16
                self.match(LabeledExprParser.ID)
                self.state = 17
                self.match(LabeledExprParser.T__0)
                self.state = 18
                self.expr(0)
                self.state = 19
                self.match(LabeledExprParser.NEWLINE)
                pass

            elif la_ == 3:
                localctx = LabeledExprParser.BlankContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 21
                self.match(LabeledExprParser.NEWLINE)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return LabeledExprParser.RULE_expr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class SingleAtomContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def atom(self):
            return self.getTypedRuleContext(LabeledExprParser.AtomContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSingleAtom" ):
                return visitor.visitSingleAtom(self)
            else:
                return visitor.visitChildren(self)


    class MulDivContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(LabeledExprParser.ExprContext)
            else:
                return self.getTypedRuleContext(LabeledExprParser.ExprContext,i)

        def MUL(self):
            return self.getToken(LabeledExprParser.MUL, 0)
        def DIV(self):
            return self.getToken(LabeledExprParser.DIV, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMulDiv" ):
                return visitor.visitMulDiv(self)
            else:
                return visitor.visitChildren(self)


    class AddSubContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(LabeledExprParser.ExprContext)
            else:
                return self.getTypedRuleContext(LabeledExprParser.ExprContext,i)

        def ADD(self):
            return self.getToken(LabeledExprParser.ADD, 0)
        def SUB(self):
            return self.getToken(LabeledExprParser.SUB, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAddSub" ):
                return visitor.visitAddSub(self)
            else:
                return visitor.visitChildren(self)


    class FactorialContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(LabeledExprParser.ExprContext,0)

        def FACT(self):
            return self.getToken(LabeledExprParser.FACT, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFactorial" ):
                return visitor.visitFactorial(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = LabeledExprParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 4
        self.enterRecursionRule(localctx, 4, self.RULE_expr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            localctx = LabeledExprParser.SingleAtomContext(self, localctx)
            self._ctx = localctx
            _prevctx = localctx

            self.state = 25
            self.atom()
            self._ctx.stop = self._input.LT(-1)
            self.state = 37
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,3,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 35
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
                    if la_ == 1:
                        localctx = LabeledExprParser.MulDivContext(self, LabeledExprParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 27
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 28
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==4 or _la==5):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 29
                        self.expr(5)
                        pass

                    elif la_ == 2:
                        localctx = LabeledExprParser.AddSubContext(self, LabeledExprParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 30
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 31
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==6 or _la==7):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 32
                        self.expr(4)
                        pass

                    elif la_ == 3:
                        localctx = LabeledExprParser.FactorialContext(self, LabeledExprParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 33
                        if not self.precpred(self._ctx, 1):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                        self.state = 34
                        self.match(LabeledExprParser.FACT)
                        pass

             
                self.state = 39
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,3,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class AtomContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return LabeledExprParser.RULE_atom

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class TanContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def TAN(self):
            return self.getToken(LabeledExprParser.TAN, 0)
        def expr(self):
            return self.getTypedRuleContext(LabeledExprParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTan" ):
                return visitor.visitTan(self)
            else:
                return visitor.visitChildren(self)


    class ParensContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(LabeledExprParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParens" ):
                return visitor.visitParens(self)
            else:
                return visitor.visitChildren(self)


    class LnContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LN(self):
            return self.getToken(LabeledExprParser.LN, 0)
        def expr(self):
            return self.getTypedRuleContext(LabeledExprParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLn" ):
                return visitor.visitLn(self)
            else:
                return visitor.visitChildren(self)


    class SqrtContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def SQRT(self):
            return self.getToken(LabeledExprParser.SQRT, 0)
        def expr(self):
            return self.getTypedRuleContext(LabeledExprParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSqrt" ):
                return visitor.visitSqrt(self)
            else:
                return visitor.visitChildren(self)


    class LogContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LOG(self):
            return self.getToken(LabeledExprParser.LOG, 0)
        def expr(self):
            return self.getTypedRuleContext(LabeledExprParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLog" ):
                return visitor.visitLog(self)
            else:
                return visitor.visitChildren(self)


    class CosContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def COS(self):
            return self.getToken(LabeledExprParser.COS, 0)
        def expr(self):
            return self.getTypedRuleContext(LabeledExprParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCos" ):
                return visitor.visitCos(self)
            else:
                return visitor.visitChildren(self)


    class NumContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUM(self):
            return self.getToken(LabeledExprParser.NUM, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNum" ):
                return visitor.visitNum(self)
            else:
                return visitor.visitChildren(self)


    class SinContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def SIN(self):
            return self.getToken(LabeledExprParser.SIN, 0)
        def expr(self):
            return self.getTypedRuleContext(LabeledExprParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSin" ):
                return visitor.visitSin(self)
            else:
                return visitor.visitChildren(self)


    class IdContext(AtomContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a LabeledExprParser.AtomContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(LabeledExprParser.ID, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitId" ):
                return visitor.visitId(self)
            else:
                return visitor.visitChildren(self)



    def atom(self):

        localctx = LabeledExprParser.AtomContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_atom)
        try:
            self.state = 76
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [16]:
                localctx = LabeledExprParser.NumContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 40
                self.match(LabeledExprParser.NUM)
                pass
            elif token in [15]:
                localctx = LabeledExprParser.IdContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 41
                self.match(LabeledExprParser.ID)
                pass
            elif token in [2]:
                localctx = LabeledExprParser.ParensContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 42
                self.match(LabeledExprParser.T__1)
                self.state = 43
                self.expr(0)
                self.state = 44
                self.match(LabeledExprParser.T__2)
                pass
            elif token in [9]:
                localctx = LabeledExprParser.SinContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 46
                self.match(LabeledExprParser.SIN)
                self.state = 47
                self.match(LabeledExprParser.T__1)
                self.state = 48
                self.expr(0)
                self.state = 49
                self.match(LabeledExprParser.T__2)
                pass
            elif token in [10]:
                localctx = LabeledExprParser.CosContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 51
                self.match(LabeledExprParser.COS)
                self.state = 52
                self.match(LabeledExprParser.T__1)
                self.state = 53
                self.expr(0)
                self.state = 54
                self.match(LabeledExprParser.T__2)
                pass
            elif token in [11]:
                localctx = LabeledExprParser.TanContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 56
                self.match(LabeledExprParser.TAN)
                self.state = 57
                self.match(LabeledExprParser.T__1)
                self.state = 58
                self.expr(0)
                self.state = 59
                self.match(LabeledExprParser.T__2)
                pass
            elif token in [12]:
                localctx = LabeledExprParser.SqrtContext(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 61
                self.match(LabeledExprParser.SQRT)
                self.state = 62
                self.match(LabeledExprParser.T__1)
                self.state = 63
                self.expr(0)
                self.state = 64
                self.match(LabeledExprParser.T__2)
                pass
            elif token in [13]:
                localctx = LabeledExprParser.LnContext(self, localctx)
                self.enterOuterAlt(localctx, 8)
                self.state = 66
                self.match(LabeledExprParser.LN)
                self.state = 67
                self.match(LabeledExprParser.T__1)
                self.state = 68
                self.expr(0)
                self.state = 69
                self.match(LabeledExprParser.T__2)
                pass
            elif token in [14]:
                localctx = LabeledExprParser.LogContext(self, localctx)
                self.enterOuterAlt(localctx, 9)
                self.state = 71
                self.match(LabeledExprParser.LOG)
                self.state = 72
                self.match(LabeledExprParser.T__1)
                self.state = 73
                self.expr(0)
                self.state = 74
                self.match(LabeledExprParser.T__2)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[2] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 1)
         




