# Generated from LabeledExpr.g4 by ANTLR 4.13.0
from antlr4 import *
if "." in __name__:
    from .LabeledExprParser import LabeledExprParser
else:
    from LabeledExprParser import LabeledExprParser

# This class defines a complete generic visitor for a parse tree produced by LabeledExprParser.

class LabeledExprVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by LabeledExprParser#prog.
    def visitProg(self, ctx:LabeledExprParser.ProgContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#printExpr.
    def visitPrintExpr(self, ctx:LabeledExprParser.PrintExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#assign.
    def visitAssign(self, ctx:LabeledExprParser.AssignContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#blank.
    def visitBlank(self, ctx:LabeledExprParser.BlankContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#singleAtom.
    def visitSingleAtom(self, ctx:LabeledExprParser.SingleAtomContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#MulDiv.
    def visitMulDiv(self, ctx:LabeledExprParser.MulDivContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#AddSub.
    def visitAddSub(self, ctx:LabeledExprParser.AddSubContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#factorial.
    def visitFactorial(self, ctx:LabeledExprParser.FactorialContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#num.
    def visitNum(self, ctx:LabeledExprParser.NumContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#id.
    def visitId(self, ctx:LabeledExprParser.IdContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#parens.
    def visitParens(self, ctx:LabeledExprParser.ParensContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#sin.
    def visitSin(self, ctx:LabeledExprParser.SinContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#cos.
    def visitCos(self, ctx:LabeledExprParser.CosContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#tan.
    def visitTan(self, ctx:LabeledExprParser.TanContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#sqrt.
    def visitSqrt(self, ctx:LabeledExprParser.SqrtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#ln.
    def visitLn(self, ctx:LabeledExprParser.LnContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by LabeledExprParser#log.
    def visitLog(self, ctx:LabeledExprParser.LogContext):
        return self.visitChildren(ctx)



del LabeledExprParser