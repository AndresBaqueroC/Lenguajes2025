import java.util.HashMap;
import java.util.Map;
import java.lang.Math;

public class EvalVisitor extends LabeledExprBaseVisitor<Double> {
    // "Memoria" para almacenar variables
    Map<String, Double> memory = new HashMap<String, Double>();
    
    // ID '=' expr NEWLINE
    @Override
    public Double visitAssign(LabeledExprParser.AssignContext ctx) {
        String id = ctx.ID().getText();
        Double value = visit(ctx.expr());
        memory.put(id, value);
        return value;
    }
    
    // expr NEWLINE
    @Override
    public Double visitPrintExpr(LabeledExprParser.PrintExprContext ctx) {
        Double value = visit(ctx.expr());
        // Formatear para mejor presentación
        if (value % 1 == 0) {
            System.out.println(value.intValue());
        } else {
            System.out.printf("%.6f%n", value);
        }
        return 0.0;
    }
    
    // NUM (números)
    @Override
    public Double visitNum(LabeledExprParser.NumContext ctx) {
        return Double.parseDouble(ctx.NUM().getText());
    }
    
    // ID
    @Override
    public Double visitId(LabeledExprParser.IdContext ctx) {
        String id = ctx.ID().getText();
        if (memory.containsKey(id)) {
            return memory.get(id);
        }
        return 0.0;
    }
    
    // expr op=('*'|'/') expr
    @Override
    public Double visitMulDiv(LabeledExprParser.MulDivContext ctx) {
        Double left = visit(ctx.expr(0));
        Double right = visit(ctx.expr(1));
        if (ctx.op.getType() == LabeledExprParser.MUL) {
            return left * right;
        } else {
            return left / right;
        }
    }
    
    // expr op=('+'|'-') expr
    @Override
    public Double visitAddSub(LabeledExprParser.AddSubContext ctx) {
        Double left = visit(ctx.expr(0));
        Double right = visit(ctx.expr(1));
        if (ctx.op.getType() == LabeledExprParser.ADD) {
            return left + right;
        } else {
            return left - right;
        }
    }
    
    // '(' expr ')'
    @Override
    public Double visitParens(LabeledExprParser.ParensContext ctx) {
        return visit(ctx.expr());
    }
    
    // sin(expr)
    @Override
    public Double visitSin(LabeledExprParser.SinContext ctx) {
        Double value = visit(ctx.expr());
        return Math.sin(Math.toRadians(value));
    }
    
    // cos(expr)
    @Override
    public Double visitCos(LabeledExprParser.CosContext ctx) {
        Double value = visit(ctx.expr());
        return Math.cos(Math.toRadians(value));
    }
    
    // tan(expr)
    @Override
    public Double visitTan(LabeledExprParser.TanContext ctx) {
        Double value = visit(ctx.expr());
        return Math.tan(Math.toRadians(value));
    }
    
    // sqrt(expr)
    @Override
    public Double visitSqrt(LabeledExprParser.SqrtContext ctx) {
        Double value = visit(ctx.expr());
        if (value < 0) {
            System.err.println("Error: no se número negativo: " + value);
            return Double.NaN;
        }
        return Math.sqrt(value);
    }
    
    // expr '!' 
    @Override
    public Double visitFactorial(LabeledExprParser.FactorialContext ctx) {
        Double value = visit(ctx.expr());
        
        if (value < 0 || value % 1 != 0) {
            System.err.println("Error: El factorial solo está definido para enteros no negativos: " + value);
            return Double.NaN;
        }
        
        int n = value.intValue();
        if (n == 0 || n == 1) {
            return 1.0;
        }
        
        long result = 1;
        for (int i = 2; i <= n; i++) {
            result *= i;
        }
        
        return (double) result;
    }
    
    // ln(expr)
    @Override
    public Double visitLn(LabeledExprParser.LnContext ctx) {
        Double value = visit(ctx.expr());
        if (value <= 0) {
            System.err.println("Error: El logaritmo natural solo está definido para números positivos: " + value);
            return Double.NaN;
        }
        return Math.log(value);
    }
    
    // log(expr) 
    @Override
    public Double visitLog(LabeledExprParser.LogContext ctx) {
        Double value = visit(ctx.expr());
        if (value <= 0) {
            System.err.println("Error: El logaritmo base 10 solo está definido para números positivos: " + value);
            return Double.NaN;
        }
        return Math.log10(value);
    }
    
}
