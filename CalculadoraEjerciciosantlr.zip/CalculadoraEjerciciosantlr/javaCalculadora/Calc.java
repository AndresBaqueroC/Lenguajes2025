import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;

public class Calc {
    public static void main(String[] args) throws IOException {
        String inputFile = null;
        if (args.length > 0) {
            inputFile = args[0];
        }
        
        InputStream is = System.in;
        if (inputFile != null) {
            is = new FileInputStream(inputFile);
        }
        
        try {
        
            CharStream input = CharStreams.fromStream(is);
            LabeledExprLexer lexer = new LabeledExprLexer(input);
            
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            
            LabeledExprParser parser = new LabeledExprParser(tokens);
            
            ParseTree tree = parser.prog();
            
            // Crear el visitor y visitar el árbol
            EvalVisitor eval = new EvalVisitor();
            eval.visit(tree);
            
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        } finally {
            if (is != null && is != System.in) {
                is.close();
            }
        }
    }
}
