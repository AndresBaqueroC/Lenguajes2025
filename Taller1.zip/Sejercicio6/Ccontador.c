#include <stdio.h>
#include <ctype.h>
#include <time.h>  // Para medir tiempos

int main() {
    int chars = 0, words = 0, lines = 0;
    int in_word = 0;
    char c;
    clock_t start, end;
    double cpu_time_used;

    start = clock();  // Inicia el cronómetro

    while ((c = getchar()) != EOF) {
        chars++;
        if (c == '\n') lines++;
        if (isspace(c)) {
            if (in_word) words++;
            in_word = 0;
        } else {
            in_word = 1;
        }
    }
    if (in_word) words++;  // Última palabra

    end = clock();  // Detiene el cronómetro
    cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("%8d%8d%8d\n", lines, words, chars);
    printf("Tiempo (C): %.6f segundos\n", cpu_time_used);
    return 0;
}
